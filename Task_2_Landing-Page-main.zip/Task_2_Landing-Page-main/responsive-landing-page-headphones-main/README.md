# Responsive Landing Page Headphones 🎧
## [Watch it on youtube](https://youtu.be/wXnlHIvKnTM)
### Responsive Landing Page Headphones 🎧

- Beautiful headphone landing page using HTML, CSS and JAVASCRIPT.
- Dark interface.
- With animations when scrolling.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![](/preview.png)
